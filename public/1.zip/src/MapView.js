import { MapContainer, TileLayer, Marker, Popup, Circle,useMap} from "react-leaflet";
import { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "./firebase";
import L from "leaflet";

import { generateArea, isInsideArea } from "./utils/areaUtils";

const busIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/61/61231.png",
  iconSize: [35, 35],      // bus size
  iconAnchor: [17, 35],    // bottom center
  popupAnchor: [0, -30],   // popup position
});

function FitToArea({ area }) {
  const map = useMap();

  useEffect(() => {
    map.setView(
      [area.center.lat, area.center.lng],
      8,                 // ✅ correct zoom for 80km
      { animate: true }
    );
  }, [area, map]);

  return null;
}

export default function MapView({ from, to }) {
  const [buses, setBuses] = useState([]);

  const area = generateArea(from, to);

  useEffect(() => {
    const tripsRef = ref(db, "trips");

    onValue(tripsRef, (snap) => {
      const data = snap.val() || {};
      const visible = [];

      Object.values(data).forEach((trip) => {
        Object.values(trip.drivers || {}).forEach((bus) => {
          if (isInsideArea(bus, area)) {
            visible.push(bus);
          }
        });
      });

      setBuses(visible);
    });
  }, [from, to]);

  if (!area) {
    return <p>Area not available</p>;
  }

  return (
    <MapContainer
      center={[area.center.lat, area.center.lng]}
      zoom={7}
      style={{ height: "80vh", width: "100%" }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

      {/* 🔵 SHOW AREA (for demo) */}
      <Circle
        center={[area.center.lat, area.center.lng]}
        radius={area.radiusKm * 1000}
        pathOptions={{ color: "blue", fillOpacity: 0.1 }}
      />

      {/* 🚌 SHOW BUSES INSIDE AREA */}
      {buses.map((bus, i) => (
  <Marker
    key={i}
    position={[bus.latitude, bus.longitude]}
    icon={busIcon}   // 🔥 BUS IMAGE HERE
  >
    <Popup>
      <b>Live Bus</b>
      <br />
      Speed: {bus.speed} km/h
    </Popup>
  </Marker>
))}

    </MapContainer>
  );
}
