import { Picker } from "@react-native-picker/picker";
import * as Location from "expo-location";
import { useEffect, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from "react-native";

import { TAMIL_NADU_DISTRICTS } from "../../utils/districts";
import { saveDriverLocation } from "../../utils/SaveLocation";
import useLocation from "../../utils/useLocation";

export default function Home() {
  const [tripCode, setTripCode] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const [startTime, setStartTime] = useState("");
  const [pauseTime, setPauseTime] = useState("");
  const [resumeTime, setResumeTime] = useState("");
  const [endTime, setEndTime] = useState("");

  const [status, setStatus] = useState<"idle" | "started" | "paused" | "ended">("idle");

  const driverId = "9876543210";

  // ✅ MySQL-friendly time (HH:MM:SS)
  const getTime = () => new Date().toTimeString().slice(0, 8);

  // GPS (UI only; DB-ku pogaadhu)
  const location =
    useLocation(status === "started") as Location.LocationObjectCoords | null;

  useEffect(() => {
    if (location && status === "started") {
      saveDriverLocation(driverId, tripCode, location);
    }
  }, [location, status]);

  // 🔥 PHP-ku data anuppura function
  function sendTripToServer(
    tripStatus: "started" | "paused" | "resumed" | "ended",
    timeValue: string
  ) {
    fetch("http://192.168.43.172:8080/bus_project/save_trip.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:
        "trip_code=" + tripCode +
        "&from_location=" + from +
        "&to_location=" + to +
        "&time=" + timeValue +
        "&status=" + tripStatus,
    })
      .then((r) => r.text())
      .then((t) => console.log("SERVER:", t))
      .catch((e) => console.log("ERR:", e));
  }

  function startTrip() {
    if (!tripCode || !from || !to) {
      alert("Enter trip code, From and To");
      return;
    }
    Keyboard.dismiss();
    const t = getTime();
    setStartTime(t);
    setStatus("started");
    sendTripToServer("started", t);
  }

  function pauseTrip() {
    const t = getTime();
    setPauseTime(t);
    setStatus("paused");
    sendTripToServer("paused", t);
  }

  function resumeTrip() {
    const t = getTime();
    setResumeTime(t);
    setStatus("started");
    sendTripToServer("resumed", t);
  }

  function endTrip() {
    const t = getTime();
    setEndTime(t);
    setStatus("ended");
    sendTripToServer("ended", t);
  }

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.container}>
          <Text style={styles.title}>Trip Dashboard</Text>

          <TextInput
            style={styles.input}
            placeholder="Trip Code"
            keyboardType="number-pad"
            value={tripCode}
            onChangeText={(t) => setTripCode(t.replace(/[^0-9]/g, ""))}
          />

          <View style={styles.pickerBox}>
            <Picker selectedValue={from} onValueChange={(v) => { setFrom(v); if (v === to) setTo(""); }}>
              <Picker.Item label="Select From" value="" />
              {TAMIL_NADU_DISTRICTS.map((d) => <Picker.Item key={d} label={d} value={d} />)}
            </Picker>
          </View>

          <View style={styles.pickerBox}>
            <Picker selectedValue={to} onValueChange={setTo}>
              <Picker.Item label="Select To" value="" />
              {TAMIL_NADU_DISTRICTS.map((d) => (
                <Picker.Item key={d} label={d} value={d} enabled={d !== from} color={d === from ? "#999" : "#000"} />
              ))}
            </Picker>
          </View>

          {status === "idle" && (
            <TouchableOpacity style={styles.startBtn} onPress={startTrip}>
              <Text style={styles.btnText}>Start Trip</Text>
            </TouchableOpacity>
          )}

          {status === "started" && (
            <TouchableOpacity style={styles.pauseBtn} onPress={pauseTrip}>
              <Text style={styles.btnText}>Pause Trip</Text>
            </TouchableOpacity>
          )}

          {status === "paused" && (
            <TouchableOpacity style={styles.resumeBtn} onPress={resumeTrip}>
              <Text style={styles.btnText}>Resume Trip</Text>
            </TouchableOpacity>
          )}

          {(status === "started" || status === "paused") && (
            <TouchableOpacity style={styles.endBtn} onPress={endTrip}>
              <Text style={styles.btnText}>End Trip</Text>
            </TouchableOpacity>
          )}

          {(startTime || pauseTime || resumeTime || endTime) && (
            <View style={styles.timeCard}>
              <Text style={styles.timeTitle}>Trip Timings</Text>
              {startTime && <Text>Start : {startTime}</Text>}
              {pauseTime && <Text>Pause : {pauseTime}</Text>}
              {resumeTime && <Text>Resume : {resumeTime}</Text>}
              {endTime && <Text>End : {endTime}</Text>}
            </View>
          )}

          <View style={styles.gpsCard}>
            <Text style={styles.gpsTitle}>Live GPS Status</Text>
            {location ? (
              <>
                <Text style={styles.gpsText}>Latitude : {location.latitude.toFixed(6)}</Text>
                <Text style={styles.gpsText}>Longitude : {location.longitude.toFixed(6)}</Text>
              </>
            ) : (
              <Text style={styles.gpsOffText}>GPS is not active</Text>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  title: { fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20 },
  input: { borderWidth: 1, borderRadius: 10, padding: 12, marginBottom: 15 },
  pickerBox: { borderWidth: 1, borderRadius: 10, marginBottom: 15 },
  startBtn: { backgroundColor: "#1e0570", padding: 14, borderRadius: 10, marginBottom: 10 },
  pauseBtn: { backgroundColor: "#f39c12", padding: 14, borderRadius: 10, marginBottom: 10 },
  resumeBtn: { backgroundColor: "#27ae60", padding: 14, borderRadius: 10, marginBottom: 10 },
  endBtn: { backgroundColor: "#c0392b", padding: 14, borderRadius: 10, marginBottom: 10 },
  btnText: { color: "#fff", textAlign: "center", fontWeight: "bold" },
  timeCard: { marginTop: 20, padding: 15, borderRadius: 10, backgroundColor: "#f4f6fb" },
  timeTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  gpsCard: { marginTop: 25, padding: 15, borderRadius: 12, backgroundColor: "#eef1ff", borderWidth: 1, borderColor: "#c7cdfa" },
  gpsTitle: { fontSize: 16, fontWeight: "bold", color: "#1e0570", marginBottom: 8, textAlign: "center" },
  gpsText: { fontSize: 14, fontWeight: "600", textAlign: "center" },
  gpsOffText: { fontSize: 14, fontWeight: "bold", color: "#c0392b", textAlign: "center" },
});
