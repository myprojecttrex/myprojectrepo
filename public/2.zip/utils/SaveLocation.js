import { ref, update } from "firebase/database";
import { db } from "../firebase";

export async function saveDriverLocation(driverId, tripCode, coords) {
  try {
    await update(ref(db, `trips/${tripCode}/drivers/${driverId}`), {
      latitude: coords.latitude,
      longitude: coords.longitude,
      speed: coords.speed || 0,
      updatedAt: new Date().toISOString(),
    });

    console.log("✅ Location saved under trip:", tripCode);
  } catch (error) {
    console.log("❌ Error saving location:", error);
  }
}
  