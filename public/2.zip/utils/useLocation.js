import * as Location from "expo-location";
import { useEffect, useState } from "react";
import { saveDriverLocation } from "./SaveLocation"; // 👈 ADD

export default function useLocation(shouldTrack) {
  const [coords, setCoords] = useState(null);

  useEffect(() => {
    let subscription = null;

    async function startTracking() {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        console.log("❌ Location permission denied");
        return;
      }

      subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 5000,
          distanceInterval: 5,
        },
        (location) => {
          const { latitude, longitude } = location.coords;

          // 👇 UI update
          setCoords(location.coords);

          // 👇 FIREBASE WRITE 🔥
          saveDriverLocation(latitude, longitude);
        }
      );
    }

    if (shouldTrack) {
      startTracking();
    }

    return () => {
      if (subscription) {
        subscription.remove(); // GPS STOP
      }
    };
  }, [shouldTrack]);

  return coords;
}
